17.7 GRAPH PLANARITY
Code submission for part II CATAM coursework 

requirements: python 3
              matplotlib
       	      random
              sys

files: ./src/bridges.py
             core.py
             graphs.py
             main.py
       ./data/II-17-7-Platonic_4.txt
              II-17-7-Platonic_6.txt
              II-17-7-Platonic_8.txt
              II-17-7-Platonic_12.txt
              II-17-7-Platonic_20.txt
       ./output (empty directory)

To run, open terminal in folder and run
$ python3 src/main.py
